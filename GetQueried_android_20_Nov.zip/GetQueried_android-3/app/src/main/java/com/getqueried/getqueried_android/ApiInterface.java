package com.getqueried.getqueried_android;

/**
 * Created by Gaurav on 10/19/2016.
 */
public interface ApiInterface {


}
