package com.getqueried.getqueried_android.dashboard.fragments;

/**
 * Created by just_me on 07.11.16.
 */
public enum FragmentType {
    MY_QUERIES, MY_ANSWERS, NEW_QUERIES
}
