package com.getqueried.getqueried_android.adapter;

import android.view.View;

/**
 * Created by Gaurav on 10/20/2016.
 */
public interface RecyclerItemClickListener {
    public void onItemClick(View v,int pos);
}
