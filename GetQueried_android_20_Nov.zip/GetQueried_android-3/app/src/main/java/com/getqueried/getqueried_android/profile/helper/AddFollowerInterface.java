package com.getqueried.getqueried_android.profile.helper;

/**
 * Created by Gaurav on 10/14/2016.
 */
public interface AddFollowerInterface {
    public void onFollowerAdded(Object sender, Object followerId);
}
