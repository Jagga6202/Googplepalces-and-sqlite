package com.getqueried.getqueried_android.create_query.helper;

/**
 * Created by Gaurav on 10/10/2016.
 */
public interface FollowersInterface {
    public void onFollowersSelected(boolean followerStatus, int followerId);
}
