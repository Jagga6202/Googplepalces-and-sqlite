package com.getqueried.getqueried_android.registration;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.getqueried.getqueried_android.R;

public class ForgotPasswordActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
    }
}
